@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt
if errorlevel 1 python -m pip install -r requirements.txt
python -m streamlit run app.py
pause
