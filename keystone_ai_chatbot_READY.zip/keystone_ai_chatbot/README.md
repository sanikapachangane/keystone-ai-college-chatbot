# Keystone AI — College Enquiry Chatbot

A responsive, premium dark-mode college enquiry website built with Streamlit. The NLP pipeline uses custom regex tokenization, TF-IDF features, Multinomial Naive Bayes intent classification, and rule-based response selection.

## Requirements
- Python 3.10 or newer
- VS Code
- Internet connection for the optional Google Fonts import in the UI

## Run in VS Code (Windows)

1. Extract `keystone_ai_chatbot.zip`.
2. Open VS Code → **File → Open Folder** → select `keystone_ai_chatbot`.
3. Open **Terminal → New Terminal**.
4. Create a virtual environment:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, use Command Prompt terminal and run:
   ```bat
   .venv\Scripts\activate.bat
   ```

5. Install libraries:
   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

6. Start the app:
   ```powershell
   streamlit run app.py
   ```

7. Streamlit will show a local URL, normally `http://localhost:8501`. Open it in your browser.

## Project files
- `app.py` — website, UI, model training, intent prediction and chat flow.
- `intents.json` — college information, training question patterns and responses.
- `requirements.txt` — Python libraries.

## How the NLP works
1. Regex tokenization converts a question into lowercase word tokens.
2. TF-IDF represents words and two-word phrases as numeric features.
3. Multinomial Naive Bayes predicts the likely intent.
4. The response layer selects an answer from that intent's responses.
5. Low-confidence questions use a fallback response.

## Customize the college data
Edit `intents.json`. For each intent, add several varied examples in `patterns` and a suitable answer in `responses`. Keep fee amounts and admission instructions verified against official sources. Restart Streamlit after editing.

## Notes
- This is a student project prototype, not an official college service.
- College fees, admission rules, facilities, contact details and timings can change; verify them with the college.
- The model is a small classroom dataset demonstration. Add many realistic training examples and evaluate on unseen test questions before reporting accuracy.


## Windows quick start
1. Extract this ZIP first (do not run it from inside the ZIP preview).
2. Open the extracted `keystone_ai_chatbot` folder. Confirm `app.py`, `intents.json`, and `requirements.txt` are in the same folder.
3. Double-click `RUN_CHATBOT.bat`, or open PowerShell in this folder and run `python -m pip install -r requirements.txt` then `python -m streamlit run app.py`.
4. Open the Local URL printed in the terminal (usually http://localhost:8501). Keep the terminal open while using the app.
